let cwidth=350
let cheight=500
let wid=15
let hgt= 20
let y_bottom=cheight -6* hgt
let x_top = cwidth-10*wid
const SHAPES = [
  [],
  [[0, 0, 0, 0], [1, 1, 1, 1], [0, 0, 0, 0], [0, 0, 0, 0]],
  [[2, 0, 0], [2, 2, 2], [0, 0, 0]],
  [[0, 0, 3], 
   [3, 3, 3], 
   [0, 0, 0]],
  [[4, 4], [4, 4]],
  [[0, 5, 5], [5, 5, 0], [0, 0, 0]],
  [[0, 6, 0], [6, 6, 6], [0, 0, 0]],
  [[7, 7, 0], [0, 7, 7], [0, 0, 0]]
];
const SHAPES_repli = [
  [],
  [[0, 0, 0, 0], [1, 1, 1, 1], [0, 0, 0, 0], [0, 0, 0, 0]],
  [[2, 0, 0], [2, 2, 2], [0, 0, 0]],
  [[0, 0, 3], 
   [3, 3, 3],
   [0, 0, 0]],
  [[4, 4], [4, 4]],
  [[0, 5, 5], [5, 5, 0], [0, 0, 0]],
  [[0, 6, 0], [6, 6, 6], [0, 0, 0]],
  [[7, 7, 0], [0, 7, 7], [0, 0, 0]]
];
const SHAPES_repli2 = [
  [],
  [[0, 0, 0, 0], [1, 1, 1, 1], [0, 0, 0, 0], [0, 0, 0, 0]],
  [[2, 0, 0], [2, 2, 2], [0, 0, 0]],
  [[0, 0, 3], 
   [3, 3, 3], 
   [0, 0, 0]],
  [[4, 4], [4, 4]],
  [[0, 5, 5], [5, 5, 0], [0, 0, 0]],
  [[0, 6, 0], [6, 6, 6], [0, 0, 0]],
  [[7, 7, 0], [0, 7, 7], [0, 0, 0]]
];
const COLORS = [
  'none',
  'cyan',
  'blue',
  'orange',
  'yellow',
  'green',
  'purple',
  'red'
];
submitLines=false
let lines=0

function textgroup(){
  push()
  textAlign(CENTER)
  rectMode(CENTER)
  push()
  noFill()
  rect(( cwidth+x_top)/2,15*hgt -5, 75, 25,10,10,10,10)
  rect(( cwidth+x_top)/2, 18*hgt -5, 95, 25,10,10,10,10)
  pop()
  textStyle(BOLD)
  textSize(25)
  text(lines, ( cwidth+x_top)/2, 2*hgt)
  text('1',( cwidth+x_top)/2, 11*hgt)
  textSize(15)
   text('Current Score',( cwidth+x_top)/2, 3*hgt)
   text('Next Block',( cwidth+x_top)/2, 8*hgt)
   text('Level',( cwidth+x_top)/2, 12*hgt)
   text('Normal',( cwidth+x_top)/2, 15*hgt)
   text('Player mode',( cwidth+x_top)/2, 18*hgt)
  //  text(mouseX+','+mouseY, mouseX, mouseY)
   textSize(30)
   text('Group 48', cwidth/2, cheight-65)
   pop()
}

class board{
  grid=[[]];
  nextBlock=[]
  row = 20
  col = 10
  //(x_top-wid)/game_Board.col*i2, y_bottom/game_Board.row*i
  xpos= (x_top)/this.col
  ypos= y_bottom/this.row
  
  reset(){
    this.grid = this.emptyBoard()
  }
  emptyBoard(){
    return Array.from({length:this.row},()=>Array(this.col).fill(0))
  }
  constructor(){
 
  }

  block_draw(){
    this.grid.forEach((row,dy)=>
    row.forEach((value,dx)=>{
      if (value>0){
        push()
        fill(COLORS[value])
        rect(dx*this.xpos, dy*this.ypos, this.xpos, this.ypos)
        pop()
      
      }
    }))

    this.nextBlock.forEach((row,dy)=>
    row.forEach((value,dx)=>{
      if (value>0&&value!=4){
        push()
        fill(COLORS[value])
        rect(dx*this.xpos+240, dy*this.ypos+5*hgt, this.xpos, this.ypos)
        pop()
      
      }else if (value==4){
        push()
        fill(COLORS[value])
        rect(dx*this.xpos+255, dy*this.ypos+5*hgt, this.xpos, this.ypos)
        pop()
      }
    }))
    
  }

   block_fixed(){
     piece.shape.forEach((row,dy)=>{
      row.forEach((value,dx)=>{
        if(value>0){
          let x = piece.start_x + dx+piece.rect_xpos;
          let y = piece.start_y + dy+piece.rect_ypos
          this.grid[y][x]=value
        }
        
      })
    })
  }

  line_clear(){
    
    this.grid.forEach((row, y) => {
      // If every value is greater than zero then we have a full row.
      if (row.every((value) => value > 0)) {

        // Remove the row.
        this.grid.splice(y, 1);

        // Add zero filled row at the top.
        this.grid.unshift(Array(this.col).fill(0));
        lines+=100
      }
    });

  }
}

let game_Board = new board()

setInterval(() => {


  if(valid_move(3)&&valid_move(4)){piece.rect_ypos+=1;submitLines=false}
  else{piece.visible=false
    
    if (valid_move(4))
      {game_Board.block_fixed()
      piece.spawn_position()
      if(valid_move(4)){
        
        piece.spawn()
        piece.block_shape()}
      }
      else if(submitLines==false){
        submitLines=true
        console.log(lines)
        submitline()
      } 
    }

 }, 500);
class Piece{
  shape=[[]]
  sh1
  shape_repli=[[]]
  visible= false
  spawn_position(){
  
    this.start_x=5
   this.start_y=0
   this.snum = this.sh1
   this.shape= SHAPES[this.snum]
   this.rect_xpos=0
   this.rect_ypos=0
  }
  block_shape(){
    this.sh1 = Math.floor(Math.random()*(SHAPES.length - 1)+1)
  }
  spawn(){
    
   
   this.shape_repli=SHAPES_repli[this.snum]
   this.visible = true
   
  }
  rect_xpos=0
  rect_ypos=0
  constructor(){
    this.sh1 = Math.floor(Math.random()*(SHAPES.length - 1)+1)
  }

  val=true
  draw(){
    if(this.visible==true){
      this.shape.forEach((row,y)=>
      {row.forEach((value,x)=>{
        if(value>0&&this.val==true){
          push()
          fill(COLORS[this.snum])
          rect((this.start_x+x+this.rect_xpos)*game_Board.xpos, (this.start_y+y+this.rect_ypos)*game_Board.ypos, game_Board.xpos, game_Board.ypos)
          pop()
        }
      })})
    }
    
  }
  
}
piece=new Piece()

function submitline(){
//   $.ajax({
//     type:'POST',
//     url: window.location+ 'lines',
//     // contentType: 'application/json',
//     data: {lines:lines},
//     // dataType: 'json',
//     success : function(customer){
        
//     },
//     error : function(e){
//         alert('error')
//         console.log('error: ',e)
//     }
// })
remove()

}




function valid_move(opt){
  return piece.shape.every((row,dy)=>{
    return row.every((col,dx)=>{
      let x = piece.start_x + dx+piece.rect_xpos;
      let y = piece.start_y + dy+piece.rect_ypos
     
      if(opt==1){
        return col===0 ||x*game_Board.xpos>0 && 
        (y+1)*game_Board.ypos<y_bottom &&game_Board.grid[y] && game_Board.grid[y][x-1] === 0
      }else if(opt==2){
        return col===0 || (x+1)*game_Board.xpos<x_top&&
        (y+1)*game_Board.ypos<y_bottom&&game_Board.grid[y] && game_Board.grid[y][x+1] === 0
      }else if (opt==3){
        return col===0 || (y+1)*game_Board.ypos<y_bottom&&game_Board.grid[y+1] && game_Board.grid[y+1][x] === 0
      }else if (opt==4){
        return col===0 || (y)*game_Board.ypos<y_bottom&&game_Board.grid[y] && game_Board.grid[y][x] === 0

      }
    })
  })
}

function rotation(){
  for (let y = 0; y < piece.shape_repli.length; y++) {
    for (let x = 0; x < y; x++) {
      [piece.shape_repli[x][y], piece.shape_repli[y][x]] = 
      [piece.shape_repli[y][x], piece.shape_repli[x][y]];
    }
  }
  piece.shape_repli.forEach(row => row.reverse());

  let value = piece.shape_repli.every((row,dy)=>{
    return row.every((col,dx)=>{
      let x = piece.start_x + dx+piece.rect_xpos;
      let y = piece.start_y + dy+piece.rect_ypos
      //console.log(game_Board.grid[y][x])

      return game_Board.grid[y] && game_Board.grid[y][x] === 0
    })  
  })

  piece.shape_repli.forEach(row => row.reverse());
  for (let y = 0; y < piece.shape_repli.length; y++) {
    for (let x = 0; x < y; x++) {
      [piece.shape_repli[x][y], piece.shape_repli[y][x]] = 
      [piece.shape_repli[y][x], piece.shape_repli[x][y]];
    }
  }
  
  return value
}


function keyPressed() {
    
 
    if (keyCode === LEFT_ARROW && valid_move(1)) {
      piece.rect_xpos-=1
    }
    if (keyCode === RIGHT_ARROW && valid_move(2)){
      piece.rect_xpos+=1
      //console.log(valid())
    }
    if (keyCode === DOWN_ARROW&&valid_move(3)){
      if(timer<5){
        piece.rect_ypos+=1
        timer=0
        }else if(!valid_move(3)){
          piece.visible=false
          
          if (valid_move(4)){
            
          game_Board.block_fixed()
          piece.spawn_position()
          piece.spawn()
          piece.block_shape()
          }
      }
    }
      
     // piece.val=false
    
    if (keyCode===UP_ARROW && rotation()){
        for (let y = 0; y < piece.shape.length; y++) {
          for (let x = 0; x < y; x++) {
            [piece.shape[x][y], piece.shape[y][x]] = 
            [piece.shape[y][x], piece.shape[x][y]];
          }
        }
        piece.shape.forEach(row => row.reverse());
        for (let y = 0; y < piece.shape_repli.length; y++) {
          for (let x = 0; x < y; x++) {
            [piece.shape_repli[x][y], piece.shape_repli[y][x]] = 
            [piece.shape_repli[y][x], piece.shape_repli[x][y]];
          }
        }
        
    }
    
    
 
}
let timer=0
function keydown(){
  
  if (keyIsDown(DOWN_ARROW)&&valid_move(3)){
    if(timer==5){
      piece.rect_ypos+=1
      timer=0
      }else if(!valid_move(3)){
        piece.visible=false
        
        if (valid_move(4)){
          
        game_Board.block_fixed()
        piece.spawn_position()
        piece.spawn()
        piece.block_shape()
        }
    }else{timer+=1}
  }
}
function playgame(){
  lines=0
  $('#errormsg').empty()
  $('#postResultDiv').empty()
  $('#errormsg').load('game.html')
}

function score(){
  $('#errormsg').empty()
  $('#postResultDiv').empty()
  $('#postResultDiv').html('<br><br><p>Your score right before: '+ lines+'</p>')

}

function config(){
  lines=0
  $('#errormsg').empty()
  $('#postResultDiv').empty()
  $('#postResultDiv').load('config.html')
}

function startup(){
  lines=0
  $('#errormsg').empty()
  $('#postResultDiv').empty()
  $('#postResultDiv').load('start.html')

}