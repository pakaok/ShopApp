function setup() {
    piece.spawn_position()
    piece.spawn()
    piece.block_shape()
    game_Board.reset()
    
    createCanvas(cwidth, cheight)
    console.table(game_Board.grid)
    
  }
  function draw(){
    background('gray')
    translate(wid, hgt)
    game_Board.block_draw()
    game_Board.nextBlock = SHAPES_repli2[piece.sh1]
   piece.draw()
   line(0, 0, 0, y_bottom)
   line(0, y_bottom, x_top, y_bottom)
   line(x_top, y_bottom, x_top, 0)
   line(x_top, 0, 0, 0)
   game_Board.line_clear()
   textgroup()
   keydown()
   //if ( milisec % 1000 ){piece.rect_ypos+=1, console.log('o')}
   
   
   //game_Board.grid[3]=[1,1,1,1,1,1,1,1,1,0]
   //game_Board.grid[16]=[0,0,0,0,0,1,0,0,0,0]
   //game_Board.grid[14]=[0,0,0,0,0,0,0,1,0,0]
  }
  