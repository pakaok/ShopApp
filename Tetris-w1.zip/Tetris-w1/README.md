# 3815ICT-Software-Engineering-Assignment
Assignment repo using p5.play 


###### Instruction on how to run
###### 1. First make sure you are using VS Code and have the live extension installed.
###### 2. Pull down the repo and open the repo in VS Code. 
###### 3. Go to the index.html file and right click the index.html file and choose 'open with live server'. This will open and run the code in your default browser.
###### 4. Refresh the page to see changes saved in your code! 

