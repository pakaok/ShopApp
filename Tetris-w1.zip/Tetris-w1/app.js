let cwidth=300
let cheight=400
let wid=50
let hgt=50
let y_bottom=cheight-2*hgt
let x_top = cwidth-2*wid
const SHAPES = [
  [],
  [[0, 0, 0, 0], [1, 1, 1, 1], [0, 0, 0, 0], [0, 0, 0, 0]],
  [[2, 0, 0], [2, 2, 2], [0, 0, 0]],
  [[0, 0, 3], 
   [3, 3, 3], 
   [0, 0, 0]],
  [[4, 4], [4, 4]],
  [[0, 5, 5], [5, 5, 0], [0, 0, 0]],
  [[0, 6, 0], [6, 6, 6], [0, 0, 0]],
  [[7, 7, 0], [0, 7, 7], [0, 0, 0]]
];
const SHAPES_repli = [
  [],
  [[0, 0, 0, 0], [1, 1, 1, 1], [0, 0, 0, 0], [0, 0, 0, 0]],
  [[2, 0, 0], [2, 2, 2], [0, 0, 0]],
  [[0, 0, 3], 
   [3, 3, 3],
   [0, 0, 0]],
  [[4, 4], [4, 4]],
  [[0, 5, 5], [5, 5, 0], [0, 0, 0]],
  [[0, 6, 0], [6, 6, 6], [0, 0, 0]],
  [[7, 7, 0], [0, 7, 7], [0, 0, 0]]
];
const COLORS = [
  'none',
  'cyan',
  'blue',
  'orange',
  'yellow',
  'green',
  'purple',
  'red'
];
class board{
  grid=[[]];
  row = 20
  col = 10
  //(x_top-wid)/game_Board.col*i2, y_bottom/game_Board.row*i
  xpos= (x_top)/this.col
  ypos= y_bottom/this.row
  reset(){
    this.grid = this.emptyBoard()
  }
  emptyBoard(){
    return Array.from({length:this.row},()=>Array(this.col).fill(0))
  }
  block_draw(){
    this.grid.forEach((row,dy)=>
    row.forEach((value,dx)=>{
      if (value>0){
        rect(dx*this.xpos, dy*this.ypos, this.xpos, this.ypos)
      }
    }))
  }

   block_fixed(){
     piece.shape.forEach((row,dy)=>{
      row.forEach((value,dx)=>{
        if(value>0){
          let x = piece.start_x + dx+piece.rect_xpos;
          let y = piece.start_y + dy+piece.rect_ypos
          this.grid[y][x]=value
        }
        
      })
    })
  }

  line_clear(){
    let lines=0
    this.grid.forEach((row, y) => {
      // If every value is greater than zero then we have a full row.
      if (row.every((value) => value > 0)) {
        lines++;

        // Remove the row.
        this.grid.splice(y, 1);

        // Add zero filled row at the top.
        this.grid.unshift(Array(this.col).fill(0));
      }
    });

  }
}

let game_Board = new board()
function setup() {piece.spawn()
  
  game_Board.reset()
  
  createCanvas(cwidth, cheight)
  console.table(game_Board.grid)
  setInterval(() => {
    if(valid_move(3)){piece.rect_ypos+=1, console.log('o')}
    else{piece.visible=false
      game_Board.block_fixed()
      
      piece.spawn()}
    
   }, 500);
}

class Piece{
  shape=[[]]
  shape_repli=[[]]
  visible= false
  spawn(){
    this.snum = Math.floor(Math.random()*(SHAPES.length - 1)+1)
   this.shape= SHAPES[this.snum]
   
   this.start_x=5
   this.start_y=0
   this.shape_repli=SHAPES_repli[this.snum]
   this.visible = true
   this.rect_xpos=0
   this.rect_ypos=0
  }
  rect_xpos=0
  rect_ypos=0
  constructor(){
    this.color='red'
  }

  val=true
  draw(){
    if(this.visible==true){
      this.shape.forEach((row,y)=>
      {row.forEach((value,x)=>{
        if(value>0&&this.val==true){
          rect((this.start_x+x+this.rect_xpos)*game_Board.xpos, (this.start_y+y+this.rect_ypos)*game_Board.ypos, game_Board.xpos, game_Board.ypos)
        }
      })})
    }
    
  }

}
piece=new Piece()

function draw(){
  background('gray')
  translate(wid, hgt)
  game_Board.block_draw()
 piece.draw()
 line(0, 0, 0, y_bottom)
 line(0, y_bottom, x_top, y_bottom)
 line(x_top, y_bottom, x_top, 0)
 line(x_top, 0, 0, 0)
 game_Board.line_clear()
 
 //if ( milisec % 1000 ){piece.rect_ypos+=1, console.log('o')}
 
 
 //game_Board.grid[18]=[1,1,1,1,1,1,1,1,1,1]
 //game_Board.grid[16]=[0,0,0,0,0,1,0,0,0,0]
 //game_Board.grid[14]=[0,0,0,0,0,0,0,1,0,0]
}


function valid_move(opt){
  return piece.shape.every((row,dy)=>{
    return row.every((col,dx)=>{
      let x = piece.start_x + dx+piece.rect_xpos;
      let y = piece.start_y + dy+piece.rect_ypos
     
      if(opt==1){
        return col===0 ||x*game_Board.xpos>0 && 
        (y+1)*game_Board.ypos<y_bottom &&game_Board.grid[y] && game_Board.grid[y][x-1] === 0
      }else if(opt==2){
        return col===0 || (x+1)*game_Board.xpos<x_top&&
        (y+1)*game_Board.ypos<y_bottom&&game_Board.grid[y] && game_Board.grid[y][x+1] === 0
      }else if (opt==3){
        return col===0 || (y+1)*game_Board.ypos<y_bottom&&game_Board.grid[y+1] && game_Board.grid[y+1][x] === 0
      }
    })
  })
}

function rotation(){
  for (let y = 0; y < piece.shape_repli.length; y++) {
    for (let x = 0; x < y; x++) {
      [piece.shape_repli[x][y], piece.shape_repli[y][x]] = 
      [piece.shape_repli[y][x], piece.shape_repli[x][y]];
    }
  }
  piece.shape_repli.forEach(row => row.reverse());

  let value = piece.shape_repli.every((row,dy)=>{
    return row.every((col,dx)=>{
      let x = piece.start_x + dx+piece.rect_xpos;
      let y = piece.start_y + dy+piece.rect_ypos
      //console.log(game_Board.grid[y][x])

      return game_Board.grid[y] && game_Board.grid[y][x] === 0
    })  
  })

  piece.shape_repli.forEach(row => row.reverse());
  for (let y = 0; y < piece.shape_repli.length; y++) {
    for (let x = 0; x < y; x++) {
      [piece.shape_repli[x][y], piece.shape_repli[y][x]] = 
      [piece.shape_repli[y][x], piece.shape_repli[x][y]];
    }
  }
  
  return value
}


function keyPressed() {
    
 
    if (keyCode === LEFT_ARROW && valid_move(1)) {
      piece.rect_xpos-=1
    }
    if (keyCode === RIGHT_ARROW && valid_move(2)){
      piece.rect_xpos+=1
      //console.log(valid())
    }
    
      if(keyCode === DOWN_ARROW&&valid_move(3)){
        piece.rect_ypos+=1
      }else if(!valid_move(3)){
        piece.visible=false
        game_Board.block_fixed()
        
        piece.spawn()}
      
     // piece.val=false
    
    if (keyCode===UP_ARROW && rotation()){
        for (let y = 0; y < piece.shape.length; y++) {
          for (let x = 0; x < y; x++) {
            [piece.shape[x][y], piece.shape[y][x]] = 
            [piece.shape[y][x], piece.shape[x][y]];
          }
        }
        piece.shape.forEach(row => row.reverse());
        for (let y = 0; y < piece.shape_repli.length; y++) {
          for (let x = 0; x < y; x++) {
            [piece.shape_repli[x][y], piece.shape_repli[y][x]] = 
            [piece.shape_repli[y][x], piece.shape_repli[x][y]];
          }
        }
        piece.shape_repli.forEach(row => row.reverse());  
    }
    
    
 
}

